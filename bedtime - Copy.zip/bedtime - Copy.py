import datetime
import time
import os

# Ask the user for their bedtime
bedtime_str = input("What time do you usually go to bed? (e.g. 22:30) ")
bedtime_hour, bedtime_minute = map(int, bedtime_str.split(':'))

# Set the shutdown delay
shutdown_delay = 5 # minutes

while True:
    # Get the current time
    current_time = datetime.datetime.now()

    # Calculate the time until bedtime
    time_until_bedtime = datetime.datetime(current_time.year, current_time.month, current_time.day, bedtime_hour, bedtime_minute) - current_time

    if time_until_bedtime.total_seconds() <= 0:
        # Calculate the time until shutdown
        time_until_shutdown = datetime.timedelta(minutes=shutdown_delay)
        break
    else:
        # Sleep until bedtime
        time.sleep(time_until_bedtime.total_seconds())

        # Calculate the time until shutdown
        time_until_shutdown = datetime.timedelta(minutes=shutdown_delay)

    # Sleep until shutdown
    time.sleep(time_until_shutdown.total_seconds())

    # Check if it's past bedtime
    if datetime.datetime.now().time() >= datetime.time(hour=bedtime_hour, minute=bedtime_minute):
        break

# Shut down the computer
os.system("shutdown /s /t 1")
